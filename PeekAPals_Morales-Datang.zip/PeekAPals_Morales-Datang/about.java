import greenfoot.*;

public class about extends Actor
{
    private GreenfootImage idle = new GreenfootImage("about_idle.png");
    private GreenfootImage hover = new GreenfootImage("about_hover.png");
    private GreenfootImage clicked = new GreenfootImage("about_clicked.png");
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    
    public about() {
        setImage(idle);
    }
    
    public void act() {
        if (Greenfoot.mouseMoved(null)) {
            if (Greenfoot.mouseMoved(this)) {
                setImage(hover); // When mouse hovers over button
            } else {
                setImage(idle); // When mouse leaves button
            }
        }
        
        if (Greenfoot.mousePressed(this)) {
            setImage(clicked);
            clickSound.play();
        }
        
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.delay(5);
            setImage(idle);
            Greenfoot.setWorld(new AboutWorld());
        }
    }
}
