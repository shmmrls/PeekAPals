import greenfoot.*;

public class nextButton extends Actor
{
    private GreenfootImage idle = new GreenfootImage("nextbutt_idle.png");
    private GreenfootImage hover = new GreenfootImage("nextbutt_hover.png");
    private GreenfootImage clicked = new GreenfootImage("nextbutt_clicked.png");
    private GreenfootSound clickSound = new GreenfootSound("prev_next.wav");

    // Store the CLASS of the next world (not the world itself)
    private Class<? extends World> nextWorldClass;

    public nextButton(Class<? extends World> nextWorldClass) {
        this.nextWorldClass = nextWorldClass;
        setImage(idle);
    }

    public void act() {
        if (Greenfoot.mouseMoved(null)) {
            if (Greenfoot.mouseMoved(this)) {
                setImage(hover);
            } else {
                setImage(idle);
            }
        }

        if (Greenfoot.mousePressed(this)) {
            setImage(clicked);
            Greenfoot.playSound("prev_next.wav"); // plays instantly and continues after world change
        }

        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.delay(10);
            setImage(idle);
            try {
                // Create the next world only when clicked
                World newWorld = nextWorldClass.getDeclaredConstructor().newInstance();
                Greenfoot.setWorld(newWorld);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
