import greenfoot.*;

public class hallThemeChoose extends Actor
{
    private GreenfootImage idle = new GreenfootImage("hall_theme.png");
    private GreenfootImage hover = new GreenfootImage("hall_theme_hover.png");
    private GreenfootImage clicked = new GreenfootImage("hall_theme_click.png");
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    
    public hallThemeChoose() {
        setImage(idle);
    }
    
    public void act() {
        if (Greenfoot.mouseMoved(null)) {
            if (Greenfoot.mouseMoved(this)) setImage(hover);
            else setImage(idle);
        }
        
        if (Greenfoot.mousePressed(this)) {
            setImage(clicked);
            clickSound.play();
        }
        
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.delay(5);
            setImage(idle);
            ThemeManager.setTheme("hall"); // store user's choice
            Greenfoot.setWorld(new howtoplayWorld());
        }
    }
}
