import greenfoot.*;

public class lvl2Direction extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    private GreenfootSound bgMusic = new GreenfootSound("direction.wav");
    
    
    public lvl2Direction()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("directiontwo.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        bgMusic.play();
        
        if (Greenfoot.isKeyDown("enter")) {
            Greenfoot.setWorld(new levelTwoWorld());
            clickSound.play();
            bgMusic.stop();
        }
    }
}
    