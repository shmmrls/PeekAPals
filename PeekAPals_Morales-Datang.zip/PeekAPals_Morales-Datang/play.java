    import greenfoot.*;

public class play extends Actor
{
    private GreenfootImage idle = new GreenfootImage("play_idle.png");
    private GreenfootImage hover = new GreenfootImage("play_hover.png");
    private GreenfootImage clicked = new GreenfootImage("play_clicked.png");
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav"); // your sound file
    
    public play() {
        setImage(idle);
    }
    
    public void act() {
        if (Greenfoot.mouseMoved(null)) {
            if (Greenfoot.mouseMoved(this)) {
                setImage(hover); // when mouse hovers
            } else {
                setImage(idle); // when mouse leaves
            }
        }
        
       if (Greenfoot.mousePressed(this)) {
            setImage(clicked);
            Greenfoot.playSound("clicked.wav"); // plays instantly and continues after world change
        }
        
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.delay(10);
            setImage(idle);
            Greenfoot.setWorld(new chooseCategory()); // Replace with your actual game world
        }
    }
}
