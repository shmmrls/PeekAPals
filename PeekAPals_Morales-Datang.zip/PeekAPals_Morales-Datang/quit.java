import greenfoot.*;

public class quit extends Actor
{
    private GreenfootImage idle = new GreenfootImage("quit_idle.png");
    private GreenfootImage hover = new GreenfootImage("quit_hover.png");
    private GreenfootImage clicked = new GreenfootImage("quit_clicked.png");
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    private GreenfootSound byeSound = new GreenfootSound("goodbye.wav");
    
    public quit() {
        setImage(idle);
    }
    
    public void act() {
        if (Greenfoot.mouseMoved(null)) {
            if (Greenfoot.mouseMoved(this)) {
                setImage(hover); // Hover effect
            } else {
                setImage(idle); // Return to idle when not hovered
            }
        }
        
        if (Greenfoot.mousePressed(this)) {
            setImage(clicked);
            clickSound.play();
        }
        
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.delay(5);
            Greenfoot.stop();
            byeSound.play();
        }
    }
}
