import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class chooseCategory extends World
{
    public chooseCategory()
    {    
        // Create a new world with 400x630 cells, each cell is 1x1 pixel
        super(466, 608, 1);
        
        // Load the background image
        GreenfootImage bg = new GreenfootImage("choose-theme.png");
        
        // Scale the image to fit the world size
        bg.scale(getWidth(), getHeight());
        
        // Set the scaled image as the background
        setBackground(bg);
        
        addObject(new themeChoose(), 232, 240);
        addObject(new hallThemeChoose(), 232, 470);

        
        addObject(new homeButton(), 65, 550);

    }
}
