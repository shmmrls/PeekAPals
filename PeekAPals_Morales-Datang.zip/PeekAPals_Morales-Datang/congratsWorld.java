import greenfoot.*;

public class congratsWorld extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    
    public congratsWorld()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("congrats.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        
        if (Greenfoot.isKeyDown("escape")) {
            Greenfoot.setWorld(new bye());
            clickSound.play();
        }
    }
}
    