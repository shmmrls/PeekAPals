public class ThemeManager {
    public static String currentTheme = "default"; // default or hall

    public static void setTheme(String theme) {
        currentTheme = theme;
    }

    public static String getTheme() {
        return currentTheme;
    }
}
