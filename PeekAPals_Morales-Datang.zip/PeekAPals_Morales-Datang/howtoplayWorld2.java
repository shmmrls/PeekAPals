import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class howtoplayWorld2 extends World
{
    public howtoplayWorld2()
    {    
        // Create a new world with 400x630 cells, each cell is 1x1 pixel
        super(466, 608, 1);
        
        
        GreenfootImage bg = new GreenfootImage("howtoplay2.png");
        
        
        bg.scale(getWidth(), getHeight());
        
        
        setBackground(bg);
       
        addObject(new prevButton(howtoplayWorld.class), 170, 550);
        addObject(new nextButton(readytopractice.class), 280, 550);
    }
}
