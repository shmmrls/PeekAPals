import greenfoot.*;
public class Mole extends Actor
{
    private World world;
    private GreenfootSound goodSound = new GreenfootSound("pop_good.wav");
    private boolean isDead = false;
    private int deadTimer = 0;
    
    private String aliveImage;
    private String deadImage;
    
    public Mole(World world) {
        this.world = world;

        if (ThemeManager.getTheme().equals("hall")) {
            aliveImage = "hall_mole.png";
            deadImage = "hall_dead.png";
        } else {
            aliveImage = "mole.png";
            deadImage = "dead.png";
        }

        setImage(aliveImage);
    }
    
    public void act() {
        if (isDead) {
            deadTimer++;
            if (deadTimer >= 30) {
                isDead = false;
                deadTimer = 0;
                setImage(aliveImage);
            }
        }
    }
    
    public void handleClick() {
        if (!isDead) {
            isDead = true;
            setImage(deadImage);
            goodSound.play();

            if (world instanceof practiceLevel) {
                ((practiceLevel) world).hitMole();
            } else if (world instanceof levelOneWorld) {
                ((levelOneWorld) world).hitMole();
            } else if (world instanceof levelTwoWorld) {
                ((levelTwoWorld) world).hitMole();
            } else if (world instanceof levelThreeWorld) {
                ((levelThreeWorld) world).hitMole();
            } else if (world instanceof levelFourWorld) {
                ((levelFourWorld) world).hitMole();
            } else if (world instanceof levelFiveWorld) {
                ((levelFiveWorld) world).hitMole();
            }
        }
    }
}
