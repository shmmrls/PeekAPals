import greenfoot.*;

public class lvl3Direction extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    private GreenfootSound bgMusic = new GreenfootSound("direction.wav");
    
    
    public lvl3Direction()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("directionthree.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        bgMusic.play();
        
        if (Greenfoot.isKeyDown("enter")) {
            Greenfoot.setWorld(new levelThreeWorld());
            clickSound.play();
            bgMusic.stop();
        }
    }
}
    