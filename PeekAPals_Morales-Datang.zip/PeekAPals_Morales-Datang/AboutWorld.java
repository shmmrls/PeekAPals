import greenfoot.*;

public class AboutWorld extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    
    public AboutWorld()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("aboutscreen.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        
        if (Greenfoot.isKeyDown("escape")) {
            Greenfoot.setWorld(new MyWorld());
            clickSound.play();
        }
    }
}
    