import greenfoot.*;

public class themeChoose extends Actor
{
    private GreenfootImage idle = new GreenfootImage("theme.png");
    private GreenfootImage hover = new GreenfootImage("theme_hover.png");
    private GreenfootImage clicked = new GreenfootImage("theme_click.png");
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    
    public themeChoose() {
        setImage(idle);
    }
    
    public void act() {
        if (Greenfoot.mouseMoved(null)) {
            if (Greenfoot.mouseMoved(this)) setImage(hover);
            else setImage(idle);
        }
        
        if (Greenfoot.mousePressed(this)) {
            setImage(clicked);
            clickSound.play();
        }
        
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.delay(5);
            setImage(idle);
            ThemeManager.setTheme("default"); // store user's choice
            Greenfoot.setWorld(new howtoplayWorld());
        }
    }
}
