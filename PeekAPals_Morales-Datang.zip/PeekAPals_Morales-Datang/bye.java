import greenfoot.*;

public class bye extends World
{
    private GreenfootSound byeSound = new GreenfootSound("goodbye.wav");
    private boolean hasPlayed = false;

    public bye()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("goodbye.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }

    public void act() {
        if (!hasPlayed) {
            byeSound.play();        // play once
            hasPlayed = true;       // mark it as played
        }

        // Wait until the sound finishes before stopping
        if (hasPlayed && !byeSound.isPlaying()) {
            Greenfoot.delay(10);    // short pause before closing
            Greenfoot.stop();       // stop the simulation
        }
    }
}
