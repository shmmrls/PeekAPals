import greenfoot.*;

public class prevButton extends Actor
{
    private GreenfootImage idle = new GreenfootImage("prevbutt_idle.png");
    private GreenfootImage hover = new GreenfootImage("prevbutt_hover.png");
    private GreenfootImage clicked = new GreenfootImage("prevbutt_clicked.png");
    private GreenfootSound clickSound = new GreenfootSound("prev_next.wav");

    private Class<? extends World> prevWorldClass; // store the CLASS, not an instance

    public prevButton(Class<? extends World> prevWorldClass) {
        this.prevWorldClass = prevWorldClass;
        setImage(idle);
    }

    public void act() {
        if (Greenfoot.mouseMoved(null)) {
            setImage(Greenfoot.mouseMoved(this) ? hover : idle);
        }

        if (Greenfoot.mousePressed(this)) {
                setImage(clicked);
                Greenfoot.playSound("prev_next.wav"); // plays instantly and continues after world change
            }

        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.delay(10);
            setImage(idle);
            try {
                // Create a new instance of the target world dynamically
                World newWorld = prevWorldClass.getDeclaredConstructor().newInstance();
                Greenfoot.setWorld(newWorld);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
