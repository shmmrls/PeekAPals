import greenfoot.*;

public class levelUpToLvl1 extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    private GreenfootSound bgMusic = new GreenfootSound("direction.wav");
    
    public levelUpToLvl1()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("lvlupto1.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        
        if (Greenfoot.isKeyDown("space")) {
            Greenfoot.setWorld(new lvl1Direction());
            clickSound.play();
        }
    }
}
    