import greenfoot.*;
import java.util.Random;

public class levelThreeWorld extends World
{
    private Mole mole;
    private NotMole notMole;
    private PawCursor pawCursor;
    private int score = 0;
    private int seconds = 20; 

    private GreenfootSound correctSound = new GreenfootSound("ready_to_play.mp3");
    private GreenfootSound correctSound2 = new GreenfootSound("okayokay.wav");
    private GreenfootSound gameOverSound = new GreenfootSound("game_over.wav");
    private GreenfootSound bgMusic; 

    private int moleTimer = 0;
    private int notMoleTimer = 0;
    private int lastMolePosition = 0;
    private int lastNotMolePosition = 0;
    private Random rnd = new Random();

    private SimpleTimer countdownTimer = new SimpleTimer();
    
    public levelThreeWorld()
    {    
        super(466, 608, 1);
        if (ThemeManager.getTheme().equals("hall")) {
            setBackground("hall_three.png");
            bgMusic = new GreenfootSound("hall_bgmusic.mp3");
        } else {
            setBackground("level3.png");
            bgMusic = new GreenfootSound("bgmusic.mp3");
        }
        
        mole = new Mole(this);
        notMole = new NotMole(this);
        
        addObject(mole, 0, 0);
        addObject(notMole, 0, 0);
    
        moveMole();
        moveNotMole();
        
        pawCursor = new PawCursor();
        addObject(pawCursor, 0, 0);
    
        bgMusic.playLoop();
        countdownTimer.mark();
    }

    public void act() {
        updateTimers();
        updateCountdown();
        handleClicks();
    }
    
    private void handleClicks() {
        if (Greenfoot.mouseClicked(null)) {
            MouseInfo mouse = Greenfoot.getMouseInfo();
            if (mouse != null) {
                java.util.List<Actor> actorsAtMouse = getObjectsAt(mouse.getX(), mouse.getY(), Actor.class);
                
                for (Actor actor : actorsAtMouse) {
                    if (!(actor instanceof PawCursor)) {
                        if (actor instanceof Mole) {
                            ((Mole) actor).handleClick();
                            break;
                        } else if (actor instanceof NotMole) {
                            ((NotMole) actor).handleClick();
                            break;
                        }
                    }
                }
            }
        }
    }

    private void updateTimers() {
        moleTimer++;
        notMoleTimer++;

        if (moleTimer >= 75) {
            moveMole();
            moleTimer = 0;
        }

        if (notMoleTimer >= 75) {
            moveNotMole();
            notMoleTimer = 0;
        }
    }

    private void updateCountdown() {
        if (countdownTimer.millisElapsed() >= 1000) {
            seconds--;
            countdownTimer.mark();
        }
        
        int minutes = seconds / 60;
        int secs = seconds % 60;
        String timeFormatted = String.format("%02d:%02d", minutes, secs);
        showText("Time: " + timeFormatted, 384, 30);
        
        showText("Score: " + score, 70, 30);

        if (seconds <= 0) {
            gameOver();
        }
    }

    public void hitMole() {
        score++; 

        if (score >= 10) { 
            correctSound.play();
            correctSound2.play();
            bgMusic.stop();
            Greenfoot.delay(50);
            Greenfoot.setWorld(new levelUpToLvl4());
        }
    }

    public void hitNotMole() {
        gameOver();
    }

    private void gameOver() {
        bgMusic.stop();
        gameOverSound.play();
        Greenfoot.delay(50);
        Greenfoot.setWorld(new gameOverWorld());
    }

    private void moveMole() {
        int newPos;
        do {
            newPos = rnd.nextInt(9) + 1;
        } while (newPos == lastMolePosition || newPos == lastNotMolePosition);
        lastMolePosition = newPos;

        switch (newPos) {
            case 1: mole.setLocation(80, 280); break;
            case 2: mole.setLocation(233, 280); break;
            case 3: mole.setLocation(386, 280); break;
            case 4: mole.setLocation(80, 400); break;
            case 5: mole.setLocation(233, 400); break;
            case 6: mole.setLocation(386, 400); break;
            case 7: mole.setLocation(80, 520); break;
            case 8: mole.setLocation(233, 520); break;
            case 9: mole.setLocation(386, 520); break;
        }
    }

    private void moveNotMole() {
        int newPos;
        do {
            newPos = rnd.nextInt(9) + 1;
        } while (newPos == lastNotMolePosition || newPos == lastMolePosition);
        lastNotMolePosition = newPos;

        switch (newPos) {
            case 1: notMole.setLocation(80, 280); break;
            case 2: notMole.setLocation(233, 280); break;
            case 3: notMole.setLocation(386, 280); break;
            case 4: notMole.setLocation(80, 400); break;
            case 5: notMole.setLocation(233, 400); break;
            case 6: notMole.setLocation(386, 400); break;
            case 7: notMole.setLocation(80, 520); break;
            case 8: notMole.setLocation(233, 520); break;
            case 9: notMole.setLocation(386, 520); break;
        }

        notMole.randomizeImage();
    }
}
