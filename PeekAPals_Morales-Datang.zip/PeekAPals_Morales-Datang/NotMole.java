import greenfoot.*;
import java.util.Random;

public class NotMole extends Actor
{
    private World world;
    private GreenfootSound badSound = new GreenfootSound("pop_bad.wav");
    private Random rnd = new Random();

    // Default theme images
    private String[] defaultImages = {
        "mymelody.png",
        "pompompurin.png",
        "cinnamoroll.png",
        "kuromi.png",
        "kerropi.png"
    };

    // Hall theme images
    private String[] hallImages = {
        "hall_mymelody.png",
        "hall_pompompurin.png",
        "hall_cinnamoroll.png",
        "hall_kuromi.png",
        "hall_kerropi.png"
    };

    // Active image set based on theme
    private String[] activeImages;

    public NotMole(World world) {
        this.world = world;

        // Choose which image set to use
        if (ThemeManager.getTheme().equals("hall")) {
            activeImages = hallImages;
        } else {
            activeImages = defaultImages;
        }

        randomizeImage();
    }

    public void act() {
        // Empty for now - clicking is handled by the world
    }

    public void handleClick() {
        badSound.play();

        if (world instanceof practiceLevel) {
            ((practiceLevel) world).hitNotMole();
        } else if (world instanceof levelOneWorld) {
            ((levelOneWorld) world).hitNotMole();
        } else if (world instanceof levelTwoWorld) {
            ((levelTwoWorld) world).hitNotMole();
        } else if (world instanceof levelThreeWorld) {
            ((levelThreeWorld) world).hitNotMole();
        } else if (world instanceof levelFourWorld) {
            ((levelFourWorld) world).hitNotMole();
        } else if (world instanceof levelFiveWorld) {
            ((levelFiveWorld) world).hitNotMole();
        }
    }

    public void randomizeImage() {
        String randomImg = activeImages[rnd.nextInt(activeImages.length)];
        setImage(randomImg);
    }
}
    