import greenfoot.*;
public class PawCursor extends Actor {
    private GreenfootImage pawUp = new GreenfootImage("paw_cursor.png");
    private GreenfootImage pawDown = new GreenfootImage("paw_cursor_hover.png");
    private static boolean cursorHidden = false;
    
    public PawCursor() {
        setImage(pawUp);
        hideCursor();
    }
    
    public void act() {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if (mouse != null) {
            setLocation(mouse.getX(), mouse.getY());
            
            if (Greenfoot.mousePressed(null)) {
                setImage(pawDown);
            } else {
                setImage(pawUp);
            }
        }
    }
    
    private void hideCursor() {
        if (!cursorHidden) {
            try {
                java.awt.image.BufferedImage cursorImg = new java.awt.image.BufferedImage(16, 16, java.awt.image.BufferedImage.TYPE_INT_ARGB);
                java.awt.Cursor blankCursor = java.awt.Toolkit.getDefaultToolkit().createCustomCursor(
                    cursorImg, new java.awt.Point(0, 0), "blank cursor");
                
                java.awt.Frame frame = (java.awt.Frame) getWorld().getClass().getSuperclass().getDeclaredMethod("getFrame").invoke(getWorld());
                if (frame != null) {
                    frame.setCursor(blankCursor);
                    cursorHidden = true;
                }
            } catch (Exception e) {
                // If hiding fails, paw cursor will just overlay system cursor
            }
        }
    }
    
    protected void addedToWorld(World world) {
        hideCursor();
    }
}