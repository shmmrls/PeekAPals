import greenfoot.*;

public class readytoplay extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    private GreenfootSound bgmusic = new GreenfootSound("next_lvl.wav");
    
    public readytoplay()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("readytoplay.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        
        if (Greenfoot.isKeyDown("r")) {
            Greenfoot.setWorld(new practiceLevel());
            clickSound.play();
        }
        
        if (Greenfoot.isKeyDown("enter")) {
            Greenfoot.setWorld(new levelUpToLvl1());
            clickSound.play();
            bgmusic.play();
        }
    }
}
    