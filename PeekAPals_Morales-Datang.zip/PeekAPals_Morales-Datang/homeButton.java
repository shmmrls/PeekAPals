import greenfoot.*;

public class homeButton extends Actor
{
    private GreenfootImage idle = new GreenfootImage("homebutt_idle.png");
    private GreenfootImage hover = new GreenfootImage("homebutt_hover.png");
    private GreenfootImage clicked = new GreenfootImage("homebutt_clicked.png");
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav"); // your sound file
    
    public homeButton() {
        setImage(idle);
    }
    
    public void act() {
        if (Greenfoot.mouseMoved(null)) {
            if (Greenfoot.mouseMoved(this)) {
                setImage(hover); // when mouse hovers
            } else {
                setImage(idle); // when mouse leaves
            }
        }
        
        if (Greenfoot.mousePressed(this)) {
            setImage(clicked);
            clickSound.play(); // play sound on click
        }
        
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.delay(5);
            setImage(idle);
            Greenfoot.setWorld(new MyWorld()); // Replace with your actual game world
        }
    }
}
