import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class MyWorld extends World
{
    public MyWorld()
    {    
        // Create a new world with 400x630 cells, each cell is 1x1 pixel
        super(466, 608, 1);

        // Load the background image
        GreenfootImage bg = new GreenfootImage("home.png");

        // Scale the image to fit the world size
        bg.scale(getWidth(), getHeight());

        // Set the scaled image as the background
        setBackground(bg);

        addObject(new play(), 232, 360);
        addObject(new about(), 232, 440);
        addObject(new quit(), 232, 520);
        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
