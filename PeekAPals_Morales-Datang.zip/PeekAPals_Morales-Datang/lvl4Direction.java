import greenfoot.*;

public class lvl4Direction extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    private GreenfootSound bgMusic = new GreenfootSound("direction.wav");
    
    
    public lvl4Direction()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("directionfour.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        bgMusic.play();
        
        if (Greenfoot.isKeyDown("enter")) {
            Greenfoot.setWorld(new levelFourWorld());
            clickSound.play();
            bgMusic.stop();
        }
    }
}
    