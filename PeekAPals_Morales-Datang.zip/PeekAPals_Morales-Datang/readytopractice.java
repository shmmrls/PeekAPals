import greenfoot.*;

public class readytopractice extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    private GreenfootSound bgMusic = new GreenfootSound("direction.wav");
    
    public readytopractice()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("readytopractice.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        
        if (Greenfoot.isKeyDown("r")) {
            Greenfoot.setWorld(new howtoplayWorld());
            clickSound.play();
        }
        
        if (Greenfoot.isKeyDown("g")) {
            Greenfoot.setWorld(new practiceLevelDirection());
            clickSound.play();
            
        }
    }
}
    