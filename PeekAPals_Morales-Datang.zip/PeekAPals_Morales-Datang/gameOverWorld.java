import greenfoot.*;

public class gameOverWorld extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    
    public gameOverWorld()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("gameover.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        
        if (Greenfoot.isKeyDown("enter")) {
            Greenfoot.setWorld(new bye());
            clickSound.play();
        }
    }
}
    