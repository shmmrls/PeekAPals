import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class howtoplayWorld extends World
{
    public howtoplayWorld()
    {    
        // Create a new world with 400x630 cells, each cell is 1x1 pixel
        super(466, 608, 1);
        
        // Load the background image
        GreenfootImage bg = new GreenfootImage("howtoplay.png");
        
        // Scale the image to fit the world size
        bg.scale(getWidth(), getHeight());
        
        // Set the scaled image as the background
        setBackground(bg);
        
        addObject(new prevButton(chooseCategory.class), 170, 550);
        addObject(new nextButton(howtoplayWorld2.class), 280, 550);

        //addObject(new quit(), 232, 520);
    }
}
