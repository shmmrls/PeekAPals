import greenfoot.*;

public class redo extends World
{
    private GreenfootSound clickSound = new GreenfootSound("clicked.wav");
    
    public redo()
    {    
        super(466, 608, 1); 
        GreenfootImage bg = new GreenfootImage("redo.png");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
    }
    
    public void act() {
        
        if (Greenfoot.isKeyDown("r")) {
            Greenfoot.setWorld(new practiceLevel());
            clickSound.play();
        }
    }
}
    